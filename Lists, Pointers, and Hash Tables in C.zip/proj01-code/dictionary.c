#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"

//The list_node_t is a node that holds a word (array of chars) and a pointer to another node. this helps us create a linked list of words.
//hash table is an array of pointers. each index is a pointer to a headed linked list made of list_node_t which are words with pointers to the next node in the list.

/*
 * Create a new hash table
 * Returns: Pointer to a table_t representing an empty hash table
 *          or NULL if an error occurs
 */
table_t *create_table() {
    table_t *table = malloc(sizeof(table_t)); //allocating memory for the hash table structure itself. 
    //creates a single instance of table_t in memory to manage entire hash table.
    
    //safety check- memory allocation did not work
    if (table == NULL){
        return NULL;
    }

    table->array = malloc(sizeof(list_node_t *) * INITIAL_HASH_TABLE_SIZE); //allocating memory for the array of pointers to the list_node_t (aka the actual words)
    if (table->array == NULL) {
        free(table);
        return NULL; //memory allocation for array failed.
    }

    //iniatialize all pointers to NULL since they are all empty lists
    for (int i=0; i < INITIAL_HASH_TABLE_SIZE; i++){
        table->array[i] = NULL;
    }

    //length of array to initial size (not just ensuring memory this time around)
    table->length = INITIAL_HASH_TABLE_SIZE;

    return table; //returning the pointer to the newly created table
}





dictionary_t *create_dictionary() {
    dictionary_t *dict = malloc(sizeof(dictionary_t));
    if (dict == NULL) {
        return NULL;
    }
    dict->table = create_table();
    if (dict->table == NULL) {
        free(dict); 
        return NULL;
    }
    dict->size = 0;
    return dict;
}

int hash_code(const char* word) {
    int i = 0;
    int hashtotal = 0;
    while (word[i] != '\0') { //stopping the while loop once it hits null
        hashtotal = hashtotal + ((int) word[i] * 7); //typecasting word[i] to int. ASCII number already provided as int values of characters. multiplying by prime number.
        i++;
    }
    return hashtotal; 
}


/*
 * Add a new word to the dictionary 
 * dict: A pointer to a dictionary to add the word to
 * word: The new word to add, as a null-terminated string
 * Returns: 0 if the word was successfully added
 *          or -1 if the word could not be added
 */

int dict_insert(dictionary_t *dict, const char *word) {
    if (dict_find(dict, word) == 0) { //making sure there are no duplicates
        //so the dict struct has a table struct that has an array of pointers to list node structs
        //list node struct is where the words are being kept

        int index = hash_code(word) % dict->table->length; //finding the hash code at the index. modulist it by the hash table array length to limit range.

        list_node_t *new_node = malloc(sizeof(list_node_t)); //creating a new list node for the word 
        //does this by declaring a new_node pointer of type list_node_t
        //malloc is used for dynamic memory allocation. it allocated a block of memory and returns a pointer to the beginning of this block
        //size of list_node_t tells malloc how much memory to allocate


        if (new_node == NULL) {
            return -1; //something went wrong with memory allocation
        }

        strcpy(new_node->word, word); // copying the word into the node. strcpy automatically puts the null at the end
        new_node->next = NULL; //each node has a next pointer initially set to null since if it is an empty list there is no next node


        //Case 1: this hash table index is empty. add it to the new node.
        if (dict->table->array[index] == NULL) {
            dict->table->array[index] = new_node;
        }
        
        //Case 2: there is a collision. We add the new node at start of linked list.
        else {
            new_node->next = dict->table->array[index]; //next pointer of list now points to the head
            dict->table->array[index] = new_node; //head of list now is the new node. goes in front.
        
        
        }
        
        dict->size++; //increase the dictionary size since we added a word
        return 0; //word was added succesfully


    }
    else {
        return -1; //word could not be added (it is probably a duplicate at this point of the code)
    }
}


/*
 * Search for a specific word in the dictionary
 * dict: A pointer to the dictionary to search
 * query: The word to search for, as a null-terminated string
 * Returns: 1 if the score was found in the dictionary, 0 otherwise
 */
int dict_find(const dictionary_t *dict, const char *query) { 
    //safety check
    if (dict == NULL || query == NULL) {
        return 0;
    }

    //hashing the query to find the right index (and improve efficiency of algorithim
    unsigned int index = hash_code(query) % dict->table->length; 

    //this is the index of the pointer to the head of the linked list that could contain the query word
    list_node_t *curr_node = dict->table->array[index];

    //traversing the linked list at the current index where word could be
    while (curr_node != NULL) {
        //strcmp will return 0 if the word we are currently on matches the query(word we are trying to find)
        if(strcmp(curr_node->word, query) == 0) {
            return 1; //word was found in the dictionary
        }
        curr_node = curr_node->next;// move to the next node
    }
    
    return 0; //word was not found
}

/*
 * Print out all words in a dictionary, in arbitrary order
 * dict: A pointer to the dictionary containing all words to print
 */
void dict_print(const dictionary_t *dict) {
    //safety check
    if (dict == NULL) {
        return;
    }

    //iterating through the buckets of the hash table
    for (int i = 0; i < dict->table->length; i++) {
        //traversing the linked list at the bucket (index of hash table array) if it is exists.
        list_node_t *curr_nodex = dict->table->array[i];
        //printf("hahaha\n");
        
        //if the dictionary is empty at that spot
        if(curr_nodex == NULL) {
            printf("\n"); //printing empty spot in the dictionary
        }
        
        else {
            while (curr_nodex != NULL) {
                //printing the current word
                printf("%s\n", curr_nodex->word);
                //going to next node in the list
                curr_nodex = curr_nodex->next;
            }
        }
    }
}


/*
 * Frees all memory used to store the contents of a dictionary: includes all words, the linked list nodes, the array of pointers in the hash table, and the structure.
 * dict: A pointer to the dictionary to free
 */
void dict_free(dictionary_t *dict) {
    //safety check
    if (dict == NULL) {
        return; 
    }

    //step 1: free every single linked list
    for(int i = 0; i < dict->table->length; i++) {
        list_node_t *curr_nodey = dict->table->array[i];

        while(curr_nodey != NULL){
            list_node_t *temp = curr_nodey;//setting the current node to a temp pointer
            curr_nodey = curr_nodey->next; //going down in the linked list
            free(temp); //freeing the temp node but contiuning on with iteraring through the linked list thanks to the reassignment
        }

    }

    //step 2: free array of pointers
    free(dict->table->array);

    //step 3: free hash table
    free(dict->table);

    //step 4: free the dictionary structure
    free(dict);
}


/*
 * Create a new dictionary containing all words listed in a text file
 * file_name: The name of the file to read words from
 * Returns: A pointer to a new dictionary containing all of the file's words
 *          or NULL if the read operation fails
 */
dictionary_t *read_dict_from_text_file(const char *file_name) {
    //opening the file for reading
    FILE *file = fopen(file_name, "r");
    
    //safety check
    if (file == NULL) {
        return NULL; //file opening did not work
    }

    //creating a new dictionary
    dictionary_t *dict = create_dictionary();
    
    //failure of creating a dictionary safety check
    if(dict == NULL) {
        fclose(file); //closing that file to avoid memory/resource leaks
        return NULL; 
    }

    //read every word in file and insert into dictionary
    char word[MAX_WORD_LEN]; //declares in memory a block big enough to sotre array of characters named word up to the max length
    //fscanf will return 1 (or the number of words, in our case 1) that was able to be inserted
    while (fscanf(file, "%s", word) == 1) {
        //do I need to check if the insert did not work?                                   
        dict_insert(dict, word); //insert in the dictionary
    }

    fclose(file); //closing the file to avoid memory leaks


    return dict; //returning a pointer to a new dictionary containing all words listed in a text file
}


/*
 * Writes the contents of a dictionary to a text file
 * dict: The dictionary to write
 * file_name: The name of the text file to write to
 * Returns: 0 on success or -1 on failure
 */
int write_dict_to_text_file(const dictionary_t *dict, const char *file_name) {
    //open file for writing. a file is found or created just by the writing mode by default.
    FILE *file = fopen(file_name, "w");
    //safety check...so if the file failed to open for writing
    if (file == NULL) {
        return -1; 
    }

    //going through the dictionary similarly to earlier parts of the oode
    for (int i = 0; i < dict->table->length; i++){
        list_node_t *curr_nodez = dict->table->array[i];
        while(curr_nodez != NULL) {
                if(fprintf(file, "%s\n", curr_nodez->word) < 0) { //fprintf returns a negative value if output error occurs so we know it failed by this point
                //the %s means we are printing strings the \n makes sure there is a newline character into the output after inserting the string
                    fclose(file);
                    return -1; //writing to file did not work so close the memory and return function
                }
            curr_nodez = curr_nodez->next; //moving onto the next node in the linked list

        }
    }
    fclose(file); //closing the file

    return 0; //return 0 if success
}
