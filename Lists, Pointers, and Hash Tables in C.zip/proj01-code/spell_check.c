#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "dictionary.h"

#define MAX_CMD_LEN 128

// A helper function to spell check a specific file (and each word)
// 'file_name': Name of the file to spell check
// 'dict': A dictionary containing correct words
//returns -1 is there was error in the spell check
//returns a 0 if all words are read succesfully
int spell_check_file(const char *file_name, const dictionary_t *dict) {
    FILE *file = fopen(file_name, "r");

    //safety check
    if (file == NULL){
        return -1; 
    }

    char word[MAX_WORD_LEN]; //making space in memory for the word array...similar logic as in dictionary_t *read_dict_from_text_file from dictionary.c code
    char sentence[100000] = {0}; //PUTS ALL WORDS IN SENTENCE TO PRINT. initally allocated to store nothing.
    int index = 0; //this is the index to keep track of the positi9on of the word array
    char ch; //holding the character read from the file currently
    
    //reading the file character by character until the end of it
    while ((ch = fgetc(file)) != EOF) {
        //if the character is a character and the index is within the max of the word
        
        if (isalpha(ch) && (index < MAX_WORD_LEN -1)) {
            word[index] = ch;
            index++; //end of the word has not been reached. continue.
        }

        else {
            word[index] = '\0'; //end the word
            strcat(sentence, word);
            
            //trying to find word in dictionary
            if (!dict_find(dict, word)) {
                //not found in Dictionary. print with an [X]
                strcat(sentence, "[X]");
            }
           
            if (isspace(ch)) {
                strcat(sentence, " ");
        
                if (ch == '\n') {
                    strcat(sentence, "\n");
                }
            }
            
            index = 0; //reset the index for the next word
        }
    }

    fclose(file);
    printf("%s\n",sentence);
    return 0; //all words were read succesfully

}

/*
 * This is in general *very* similar to the list_main file seen in lab
 */
int main(int argc, char **argv) {
    dictionary_t *dict = NULL; //declaring a variable...this is a holder for the variable
    char cmd[MAX_CMD_LEN]; //char array of the command

    //trying to load the dictionary. there are 3 cases.
    //argc is the integer count; tells us how many command-line arguments were supplied.
    
    //case 1: there are two command prompts
     if (argc == 2) {
        dict = read_dict_from_text_file(argv[1]); //second command or argv is the name of the dictionary file
        
        if (dict == NULL) {
            printf("Failed to read dictionary from text file\n");
            return -1; // exiting the program
        } else {
            printf("Dictionary successfully read from text file\n");
            }
    }

    //case 2: there are three command prompts
    if (argc == 3) {
        dict = read_dict_from_text_file(argv[1]); //the second command line is the name of the dictionary file.
        //safety check
        if (dict == NULL) {
            printf("Failed to read dictionary from text file\n");
            return -1;
        }
        else {
            printf("Dictionary successfully read from text file\n");
        }

        int spell_check_result = spell_check_file(argv[2], dict); //third command is the file to spell check
            if (spell_check_result == -1) {
                printf("Spell check failed\n");
                dict_free(dict);
                return spell_check_result;
            }
            else {
                dict_free(dict);
                return spell_check_result;
            }
    }

    //case 3(error): more than 3 commands
    else if (argc > 3) {
        printf("Too many commands.\n");
        dict_free(dict);
        return -1; // Exit the program if incorrect usage
    }

    //create a new empty dictionary if there is no dict file provided.
    if (dict == NULL) {
        dict = create_dictionary();
    }

    printf("CSCI 2021 Spell Check System\n");
    printf("Commands:\n");
    printf("  add <word>:              adds a new word to dictionary\n"); //Y
    printf("  lookup <word>:           searches for a word\n");
    printf("  print:                   shows all words currently in the dictionary\n");
    printf("  load <file_name>:        reads in dictionary from a file\n");
    printf("  save <file_name>:        writes dictionary to a file\n");
    printf("  check <file_name>: spell checks the specified file\n");
    printf("  exit:                    exits the program\n");
    
    while (1) { //the 1 is an infinite loop. will only go out of it when the user types exit or there is a break in the program (THE TWO CASES ARE NOTED DOWN BELOW)
        printf("spell_check> ");
        
        //EXITING the loop case 1: End of file (aka EOF)
        if (scanf("%s", cmd) == EOF) {
            printf("\n");
            break;
        }
        
        //add <word>
        else if (strcmp("add", cmd) == 0) {
            char word[MAX_WORD_LEN];
            scanf("%127s", word); //reading up to 127 characters...want space for newline ect. same logic throughout the rest of this main function.
            if (dict_insert(dict, word) == -1) {
                 printf("Could not add %s to the dictionary.\n", word); //if word could not be added for some reason
            }
        }

        //lookup <word>
        else if (strcmp("lookup", cmd) == 0) {
            char word[MAX_WORD_LEN];
            scanf("%127s", word); 

            //word NOT found in dictionary
            if (dict_find(dict, word) == 0) {
                 printf("'%s' not found\n", word);
            }

            //word found in dictionary
            else if (dict_find(dict, word) == 1) {
                printf("'%s' present in dictionary\n", word);
            }
        }

        //print
        else if (strcmp("print", cmd) == 0) {
            dict_print(dict);

        }

        //load <file_name>
        else if (strcmp("load", cmd) == 0) {
            char file_name[MAX_CMD_LEN];
            
            if(scanf("%127s", file_name) == 1) {
                dictionary_t *new_dict = read_dict_from_text_file(file_name);
                
                //discarding the current dictionary 
                if (new_dict) {
                    dict_free(dict);
                    dict = new_dict;
                    printf("Dictionary successfully read from text file\n");
                
                } else {
                    printf("Failed to read dictionary from text file\n");
                }
            } else {
            //no file name given for the load command
            printf("No file name was provided for load command\n");
            }
        }


        //save <file_name>
        else if (strcmp("save", cmd) == 0) {
            char file_name[MAX_CMD_LEN]; //creating a block of an array to store a string of the max length
            
            if (scanf("%s", file_name) == 1) { //reading one item from the file
                if (write_dict_to_text_file(dict, file_name) == 0) {
                    printf("Dictionary successfully written to text file\n");
                } else {
                    printf("Failed to write dictionary to text file\n");
                }
            } else {
                //no file name given for the save command
                printf("No file name was provided for save command\n");
            }
        }

        //check <file-name>
        else if (strcmp("check", cmd) == 0) {
            char file_name[MAX_CMD_LEN];

            //trying to spell-check the provided file
            if(scanf("%s", file_name) == 1) {
                int result = spell_check_file(file_name, dict);

                if (result == -1) {
                    printf("Spell check failed\n");
                }
            }
        }

        //EXITING the loop case 2: user types in exit. this is also the gateway to the unkown command loop because all conditions are checked and none match the other commands.
        else if (strcmp("exit", cmd) == 0) {
            break;
        }

        else {
            printf("Unknown command %s\n", cmd);
        }
    }

    dict_free(dict);
    return 0;
}

