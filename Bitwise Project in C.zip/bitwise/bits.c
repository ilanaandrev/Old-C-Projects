/* 
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting if the shift amount
     is less than 0 or greater than 31.


EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implement floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants. You can use any arithmetic,
logical, or comparison operations on int or unsigned data.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc program (described in the writeup) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operations (integer, logical,
     or comparison) that you are allowed to use for your implementation
     of the function.  The max operator count is checked by dlc.
     Note that assignment ('=') is not counted; you may use as many of
     these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *
 *       YOU WILL RECEIVE NO CREDIT IF YOUR CODE DOES NOT PASS THIS CHECK.
 *
 *   2. Use the btest checker to verify that your solutions produce 
 *      the correct answers.
 */


#endif


/* 
 * bitOr - x|y using only ~ and & 
 *   Example: bitOr(6, 5) = 7
 *   Legal ops: ~ &
 *   Max ops: 8
 *   Rating: 1
 */
int bitOr(int x, int y) {
  //bitOr uses De Morgan's law to turn the and into an or using negation using one line and 4 operations.
  return ~(~x & ~y);
}

/* 
 * TMax - return maximum two's complement integer 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 4
 *   Rating: 1
 */
int tmax(void) {
  //1 shifted to the left 31 bits puts a 1 as the MSB and 0's the rest of the bits. negating this would result into 0x7fffffff which is the max two's complement int
  return ~(1 << 31);
}

/* 
 * sign - return 1 if positive, 0 if zero, and -1 if negative
 *  Examples: sign(130) = 1
 *            sign(-23) = -1
 *  Legal ops: ! ~ & ^ | + << >>
 *  Max ops: 10
 *  Rating: 2
 */
int sign(int x) {
  //we check if x is negative, and if z is not_zero (aka positive but not equal to 0) by a double negation and then return the result in an or statement
  int neg= x >> 31; //right shifting by 31 and for negative numbers this results in -1. for x equals pos or 0 this would result in 0.
  //-1 for negative numbers, 0 for non-negative

  int not_zero = !!x; //makes any non-zero value one and any zero value 0.
  //1 for non-zero numbers. 0 for zero.
    
    return neg | not_zero; 
}

/* 
 * copyLSB - set all bits of result to least significant bit of x
 *   Example: copyLSB(5) = 0xFFFFFFFF, copyLSB(6) = 0x00000000
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
int copyLSB(int x) {
  //first I shift x by 31 bits (so i have the LSB as the MSB). then I shift that using arithmetic right shift by 31 bits.
  return ((x << 31) >> 31);
}

/* 
 * replaceByte(x,n,c) - Replace byte n in x with c
 *   Bytes numbered from 0 (LSB) to 3 (MSB)
 *   Examples: replaceByte(0x12345678,1,0xab) = 0x1234ab78
 *   You can assume 0 <= n <= 3 and 0 <= c <= 255
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 10
 *   Rating: 3
 */
int replaceByte(int x, int n, int c) {
  int shift = n << 3; //this multiples n by 8 so we know how many bytes to move
  int mask = ~(0xFF << shift); //shifts f by shift so that all bits are set to 1 except the bits needed to change which are set to 0.
  int shiftC = c << shift; //shift the new byte in prep for insertion
  return (x & mask) | shiftC; //clearing the target byte(s) using the AND and the mask, and then using OR for adding the new byte(s)../
}

/* 
 * rotateLeft - Rotate x to the left by n
 *   Can assume that 0 <= n <= 31
 * 
 *   Examples: rotateLeft(0x87654321,4) = 0x76543218
 *   Legal ops: ~ & ^ | + << >> !
 *   Max ops: 25
 *   Rating: 3 
 */
int rotateLeft(int x, int n) {
    //part 1: left
    //shifting x to the left by n bits. this just gets the left part of the end result.
    int left = x << n;
  
    //part 2: right
    //right shifts x subtracting 32-n. this gets the right part of the end result. WILL cause 1s in the front which we do not want.
    //with two's complement, the way to "subtract" a number is to negate it, add one. that way it is 32-n implied.
    int shift = 32 + (~n + 1);
    //the goal of the mask is to zero out the leftmost bits of the result of right shift so when we combine in the return statement, there is not a bit overlap.
    int mask = (1 << n) + ~0; //shifting 1 left by n, then subtracting 1. sets the rightmost bits to 1.
    int right = (x >> shift) & mask;
    //combining the parts 1 and 2 together
    return left | right;
}

/* 
 * bang - Compute !x without using !
 *   Examples: bang(3) = 0, bang(0) = 1
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 4 
 */
//notes: bang computed the boolean value and then negated. all numbers other than 0 will result in a 0. 0! results in 1.
int bang(int x) {
    int negx = ~x + 1; //making x negative
    int orresult = x | negx; //or x with negx
    int shiftresult = orresult >> 31; //shifting the MSB to the LSB. arithmetic right shift so F becomes more F and 0 becomes more 0.
    return shiftresult + 1; //adding 1 to convert 0xFF..F to 0 and 0x00..0 to 1. the 0xFFF.FF becomes 0 due to overflow as the 33rd bit is the one and it gets cut.
}

/*
 * bitParity - returns 1 if x contains an odd number of 0's
 *   Examples: bitParity(5) = 0, bitParity(7) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 */
int bitParity(int x) {
  //we are going to use right shifts (which are the same thing as dividing by 2)
  //we are going to solve this by dividing and conquering, cutting the bit sequence in half each time
  x ^= x >> 16;
  x ^= x >> 8;
  x ^= x >> 4;
  x ^= x >> 2;
  x ^= x >> 1;
  return (x & 1); //extracting this last bit which represents the parity
}


/*
 * floatScale4 - Return bit-level equivalent of expression 4*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned floatScale4(unsigned uf) {
    unsigned sign = uf & 0x80000000; // getting sign bit in the MSB spot.0 if positive. 1 if negative. 1 bit. it is unsigned so this is generally 0.
    unsigned exponent = uf & 0x7F800000; // getting exponent bits. 8 bits.
    unsigned fraction = uf & 0x007FFFFF; // getting the fraction part bits. 25 bits.

    // check for NaN or infinity
    if (exponent == 0x7F800000) {
        return uf;
    }
    //case 1: denormalized. exponent all 0s. signals number is very close to 0. 
   else if (exponent == 0) {
        fraction <<= 2; // multiplying the fraction by 4
        if (fraction & 0x00800000) { // overflow check
            exponent = 0x01000000; //from denorm exponent to norm CHANGED
            fraction >>= 1; //right shift fraction to lose the least significant bit
        }
        fraction &= 0x007FFFFF; // clear the 24th bit if it is set
    }
    // case 2: normalized case
    else {
      exponent += (2 << 23); //add two to the exponent to make it *4.
        if (exponent >= 0x7F800000){
            exponent = 0x7F800000; //setting exponent to inf
            fraction = 0; // clear the fraction
        }
    }
    return sign | exponent | fraction;
}

  

/* (FIX THIS ONE)
 * floatFloat2Int - Return bit-level equivalent of expression (int) f
 *   for floating point argument f.
 *   Argument is passed as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point value.
 *   Anything out of range (including NaN and infinity) should return
 *   0x80000000u.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
int floatFloat2Int(unsigned uf) {
    unsigned sign = uf & 0x80000000; // getting sign bit in the MSB spot.0 if positive. 1 if negative. 1 bit. it is unsigned so this is generally 0.
    int exponent = ((uf >> 23) & 0xFF)-127; // getting exponent bits. 8 bits. anding it with FF to remove the sign bit in front.
    unsigned fraction = uf & 0x007FFFFF;// getting the fraction part bits. 25 bits. WITHOUT the implicit leading 1.
    
    //case 1: 0 or denormm'
    if (exponent < 0) {
      return 0;
    }

    
    //case 2: overflow case. NaN or inf.
    if (exponent >= 126) {
        return 0x80000000u; // Return special out-of-range value
    }

    //case 3: normalized case
    //shift the fraction according to the exponent, converting the float to int
    //we also have to add the implicit 1 to the fraction.
    fraction = fraction | 0x00800000; //adding the implicit leading 1
    if (exponent > 23) {
        fraction <<= (exponent - 23);
    } else {
        fraction >>= (23 - exponent);
    }

    // if there is a sign bit make sure to return it with the number
    if (sign) {
        return -fraction;
    }
    return fraction;
}